# 3d-webgl-hollow-object

# Tugas Besar Grafika Komputer 1

3D WebGL Hollow Object

## Cara Menjalankan Program

Buka file `index.html` pada browser.

## Kontributor

* Gagas Praharsa Bahar (13520016)
* Bariza Haqi (13520018)
* Gregorius Moses Marevson (13520052)
